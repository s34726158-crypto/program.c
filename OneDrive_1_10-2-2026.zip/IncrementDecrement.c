#include <stdio.h>

int main()
{
    int i = 5;

    printf("i++ = %d\n", i++); // Post-increment
    printf("++i = %d\n", ++i); // Pre-increment
    printf("i-- = %d\n", i--); // Post-decrement
    printf("--i = %d\n", --i); // Pre-decrement

    return 0;
}