#include <stdio.h>
int main()
{
    int a = 45;
    float b = 12.9876;
    char c = 'Z';
    printf("Integer: %d\n", a);
    printf("Float (2 decimals): %.2f\n", b);
    printf("Float (5 decimals): %.5f\n", b);
    printf("Character: %c\n", c);
    return 0;
}