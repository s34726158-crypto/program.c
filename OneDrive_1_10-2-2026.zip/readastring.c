#include <stdio.h>

int main() {
    char str[100];

    printf("Enter a string: ");
    gets(str);

    printf("You entered: %s", str);

    return 0;
}