#include <stdio.h>
int main() {
    char name[50];
    scanf("%s", name);      
    printf("Name: %s\n", name);   
    return 0;
}
