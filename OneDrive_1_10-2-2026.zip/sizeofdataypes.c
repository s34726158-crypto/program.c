#include <stdio.h>
int main()
{
    printf('size of int:%lu bytes\n",sizeof(int));
    printf("size of float:%lu bytes\n")